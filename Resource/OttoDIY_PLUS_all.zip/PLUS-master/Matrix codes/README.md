# LED Matrix (optional)

This Repository have all open source files for @jarsoftelectrical version of the popular Otto DIY 
The Arduino code is modified from the Zowi robot, it has modified to wotk with a MAX 7219 LED MATRIX as as mouth as well as other adjustments.

Please copy all the files in the OTTO_Library folder to the Arduino IDE Library folder
The code is based on the Zowi code, modified for OTTO
Please NOTE: i have moved the BUZZER to pin D13............
Please NOTE: you need pull-down resistors on the button pins............
Please NOTE: you will need a link between A7 and +5 volt to fool low battery warnings

OTTO main program is  inside the OTTO_LEDMATRIX folder, ensure you are using the latest version of the Arduino IDE.
The modifed ZOWI main program is inside the ZOWI_BASE_v2_MATRIX folder, ensure you are using the latest version of the Arduino IDE.

Happy roboting....

Otto was inspired by another robot BoB the BiPed and programmed using code from [another open source biped robot Zowi](https://github.com/bqlabs/zowi)
