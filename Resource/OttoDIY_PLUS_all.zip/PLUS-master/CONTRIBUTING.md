# How to contribute to OttoDIY+ effectively?
Otto builders are the community of Otto DIY [sign up our mailing list](http://eepurl.com/ceWDBr)

## 1. step one to contribute is to be an Otto builder

join the Otto builder [group in thingiverse](https://www.thingiverse.com/groups/ottodiy/)

## 2. step two is to build your own Otto!
How? download all the files in [ottodiy.com](http://ottodiy.com), then check our step by step in [Hackster](https://www.hackster.io/otto/otto-build-your-own-robot-in-two-hours-5f2a1c)
build it! and show to the world that [you have MADE an Otto in Thingiverse](https://www.thingiverse.com/thing:1568652/add_instance), by just sharing your pictures.

Thanks for joining us!

## 3. step three is to publish your innovative creation related to Otto DIY 

new part design, fix an issue, idea or if the creation is definitely different but inspired on; is techinically a remix, so please [publish your REMIX in Thingiverse too](https://www.thingiverse.com/thing:1568652/add_derivative)
if you want to contribute more officially to the project [join us in the development of Otto DIY + in Hackster](https://www.hackster.io/ottoplus/otto-diy-arduino-bluetooth-robot-easy-to-3dprint-33406c)

Happy to have you as a part of the Otto Community :) and welcome!

keep sharing with us in any of our social media, friends, family [#OttoDIY](https://twitter.com/search?q=%23OttoDIY&src=typd&lang=en) and make sure more #Ottobuilder do the same everywhere.
we love to see Ottos around the world!

Interested to buy?  help us please to spread the word in Maker Faires, maker spaces, hackerspaces, schools and so on;
with enought people willing to buy, we will offer very affordable kits.

## 4. new code need to pull a request in Github
or just send us the files we will upload for you and give the apropiate credits to you as we did with all Otto builders

## Otto as Ed-tech tool
Interested to donate? 
Further plans with Otto in STEM education or looking to partner? you can contact us: camilo@ottodiy.com

For now we are rewarding the best Otto builders and as always we will do it to keep sharing this knoweledge for FREE to the society.
Regards from Otto 
o++o
